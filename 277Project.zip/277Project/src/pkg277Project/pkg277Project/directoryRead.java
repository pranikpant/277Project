package pkg277Project;

import java.io.*;
import java.text.SimpleDateFormat;
import java.text.DecimalFormat;

public class directoryRead {
    
    public static void main(String[] args) {
        File file = new File("C:\\");
        File[] files;
        files = file.listFiles();

        
    }
}   
